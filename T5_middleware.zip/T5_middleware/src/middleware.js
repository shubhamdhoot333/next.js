import { NextResponse } from "next/server";
export function middleware(request){
    return NextResponse.redirect(new URL("/login",request.url))
    // console.log("middleware");
}

export const config = {
    matcher: ['/about/:path*', '/student/:path*'],
  }