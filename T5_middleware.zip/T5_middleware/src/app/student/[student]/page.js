"use client"
function Student({params}) {
    return (
      <div>
        
         <h1>Student page</h1>
         <h4>name:{params.student}   </h4> 
         
          </div>
    )
  }
  
  export default Student