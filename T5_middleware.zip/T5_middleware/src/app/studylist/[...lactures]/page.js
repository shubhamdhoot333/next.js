"use client"
function Lacture({params}) {
    console.log("params",params)
    return (
       
        <div>
         <h1>Lacture list</h1>
         {params.lactures
}
         
          </div>
    )
  }
  
  export default Lacture