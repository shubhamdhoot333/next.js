
function Aboutstudent() {
  return (
    <div>About student</div>
  )
}

export default Aboutstudent