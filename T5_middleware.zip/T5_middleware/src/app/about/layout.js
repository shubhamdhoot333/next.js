"use client" 
import Link from "next/link"
import { usePathname } from "next/navigation";

import './about.css'
export default function Layout({ children }){
  const pathname = usePathname();
  console.log("pathname",pathname);
  return (
    <div>
      {pathname =="/about/aboutteacher"?null :
      <ul className="about-menu">
            <li>
                <h4>About Navbar</h4>
            </li>
        <li>
            <Link href="/about">About Main</Link>
        </li>
        <li>
            <Link href="/about/aboutstudent">Student About </Link>
        </li>
        <li>
            <Link href="/about/aboutteacher">Teacher About </Link>
        </li>
        </ul> }
        
        {children}
    </div>
)
}
