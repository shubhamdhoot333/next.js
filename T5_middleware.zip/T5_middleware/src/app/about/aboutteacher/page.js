

function Aboutteacher() {
  return (
    <div>About teacher page</div>
  )
}

export default Aboutteacher