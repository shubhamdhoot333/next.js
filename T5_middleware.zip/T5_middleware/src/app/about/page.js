
function About () {
  return (
    <div>
        About page 
        </div>
  )
}

export default About