"use client"
function Studylist() {
    return (
      <div>
        
         <h1>Student list</h1>
         
         
          </div>
    )
  }
  
  export default Studylist