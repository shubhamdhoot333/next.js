import Title from "./title";

async function gallarylist(){
    const response = await fetch('https://jsonplaceholder.typicode.com/albums')
    const data = await response.json()
    return data
} 

export default async function Page(){
            let dashboard= await gallarylist();
    return (
        <div>
          <h2>Dashboard</h2>
     
                  {
                     dashboard && dashboard.map((values) =>( <div>
                       <p>{values.title}</p>
                       <Title id={values.id} />
                     </div>))

                  }
        
        </div>
      )
}