"use client"
export default function Title({id}){
    return(
        <div>
            <button onClick={()=>{alert(id)}}> click here</button>
        </div>
    )
}