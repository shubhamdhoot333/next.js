"use client"
import {
    useState,
    useEffect
  } from 'react'
  
  function Dashboard() {
    const [loading, setloading] = useState(true)
    const [dashboard, setdashboard] = useState([])
  
    useEffect(() => {
      async function fetchdashboard() {
        const response = await fetch('https://jsonplaceholder.typicode.com/albums')
        const data = await response.json()
        setdashboard(data)
        setloading(false)
      }
      fetchdashboard()
    }, [])
  
    if (loading) {
      return <h2>Loading...</h2>
    }
  
    return (
      <div>
        <h2>Dashboard</h2>
       
        {
             dashboard && dashboard.map((values)=>{return ( <p>{values.title}</p>)
                
            })
        }
      </div>
    )
  }
  
  export default Dashboard